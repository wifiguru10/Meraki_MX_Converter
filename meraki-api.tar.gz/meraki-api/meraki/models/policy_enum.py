# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class PolicyEnum(object):

    """Implementation of the 'Policy' enum.

    'Deny' traffic specified by this rule

    Attributes:
        DENY: TODO: type description here.

    """

    DENY = 'deny'

