# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Settings2Enum(object):

    """Implementation of the 'Settings2' enum.

    How VLAN tagging is applied. Can be 'network default', 'ignore' or
    'custom'.

    Attributes:
        ENUM_NETWORK DEFAULT: TODO: type description here.
        IGNORE: TODO: type description here.
        CUSTOM: TODO: type description here.

    """

    ENUM_NETWORK_DEFAULT = 'network default'

    IGNORE = 'ignore'

    CUSTOM = 'custom'

