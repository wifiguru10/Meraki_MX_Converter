# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class SettingsEnum(object):

    """Implementation of the 'Settings' enum.

    How bandwidth limits are enforced. Can be 'network default', 'ignore' or
    'custom'.

    Attributes:
        ENUM_NETWORK DEFAULT: TODO: type description here.
        IGNORE: TODO: type description here.
        CUSTOM: TODO: type description here.

    """

    ENUM_NETWORK_DEFAULT = 'network default'

    IGNORE = 'ignore'

    CUSTOM = 'custom'

