# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Policy1Enum(object):

    """Implementation of the 'Policy1' enum.

    The policy applied to matching traffic. Must be 'deny'.

    Attributes:
        DENY: TODO: type description here.

    """

    DENY = 'deny'

