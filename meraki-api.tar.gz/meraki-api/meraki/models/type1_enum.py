# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type1Enum(object):

    """Implementation of the 'Type1' enum.

    The type of definition. Can be one of 'application',
    'applicationCategory', 'host', 'port', 'ipRange' or 'localNet'.

    Attributes:
        APPLICATION: TODO: type description here.
        APPLICATIONCATEGORY: TODO: type description here.
        HOST: TODO: type description here.
        PORT: TODO: type description here.
        IPRANGE: TODO: type description here.
        LOCALNET: TODO: type description here.

    """

    APPLICATION = 'application'

    APPLICATIONCATEGORY = 'applicationCategory'

    HOST = 'host'

    PORT = 'port'

    IPRANGE = 'ipRange'

    LOCALNET = 'localNet'

