# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class WpaEncryptionModeEnum(object):

    """Implementation of the 'WpaEncryptionMode' enum.

    The types of WPA encryption. ('WPA1 and WPA2' or 'WPA2 only')

    Attributes:
        ENUM_WPA1 AND WPA2: TODO: type description here.
        ENUM_WPA2 ONLY: TODO: type description here.

    """

    ENUM_WPA1_AND_WPA2 = 'WPA1 and WPA2'

    ENUM_WPA2_ONLY = 'WPA2 only'

