# -*- coding: utf-8 -*-

"""
    meraki

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class PowerTypeEnum(object):

    """Implementation of the 'PowerType' enum.

    Per switch exception (combined, redundant, useNetworkSetting)

    Attributes:
        COMBINED: TODO: type description here.
        REDUNDANT: TODO: type description here.
        USENETWORKSETTING: TODO: type description here.

    """

    COMBINED = 'combined'

    REDUNDANT = 'redundant'

    USENETWORKSETTING = 'useNetworkSetting'

